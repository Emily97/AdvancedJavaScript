import React from 'react';
import './LoadingIcon.css';

const LoadingIcon = () => {
    return(
        <div className="loader">

        </div>
    )
}

export default LoadingIcon;
